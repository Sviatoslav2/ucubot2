using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using MySql.Data.MySqlClient;
using ucubot.Model;
using Dapper;



namespace ucubot.Database
{
    public class LessonSignalRepository : ILessonSignalRepository
    {
        
        
        
        public IEnumerable<LessonSignalDto> GetSignals(MySqlConnection connection)
        {
            return connection.Query<LessonSignalDto>("SELECT lesson_signal.Id Id, lesson_signal.Timestamp Timestamp, lesson_signal.SignalType Type, student.user_id UserId FROM lesson_signal LEFT JOIN student ON (lesson_signal.student_id = student.id);").ToList();
        }

        public LessonSignalDto GetSignal(MySqlConnection connection, long id)
        {
            var queryResult = connection.Query<LessonSignalDto>("SELECT lesson_signal.Id Id, lesson_signal.Timestamp Timestamp, lesson_signal.SignalType Type, student.user_id UserId  FROM lesson_signal LEFT JOIN student ON (lesson_signal.student_id = student.id) WHERE lesson_signal.Id=" + id + ";").ToList();
            return queryResult.Count > 0 ? queryResult[0] : null;
        }

        public int CreateSignal(MySqlConnection connection, SlackMessage message)
        {	var userId = message.user_id;
	        var signalType = message.text.ConvertSlackMessageToSignalType();
	        var t0 = connection.Query<LessonSignalDto>("SELECT * FROM student WHERE user_id = @userId;", new {UserId = userId}).ToList();	
				
	        if(t0.Count == 0){
		        return 100; 
	        }
	        var id = t0[0].Id;
	        var t1 = connection.Query<LessonSignalDto>("SELECT * FROM lesson_signal WHERE student_id = @Id;", new {Id = id}).ToList();
	        if(t1.Count > 0){
		        return 409; 
	        }

				
	        var command = new MySqlCommand("INSERT INTO lesson_signal (student_id, signal_type, time_stamp) VALUES (@id, @signalType, @timeStamp);", connection);
	        command.Parameters.AddWithValue("id", id);
	        command.Parameters.AddWithValue("signalType", signalType);
	        command.Parameters.AddWithValue("timeStamp", DateTime.Now);
	        return 200;
        }
    

        public void DeleteSignal(long id,string connectionString)
        {	var connection = new MySqlConnection(connectionString);
	        var command = new MySqlCommand("DELETE FROM lesson_signal WHERE id = @id;", connection);
	        command.Parameters.AddWithValue("id", id);
        }
    }
}

