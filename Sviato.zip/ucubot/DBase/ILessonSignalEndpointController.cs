﻿namespace ucubot.DBase
{
    public interface ILessonSignalEndpointController
    {
        
    }
}